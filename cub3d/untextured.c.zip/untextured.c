/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   untextured.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rvena <rvena@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/28 11:16:20 by rvena             #+#    #+#             */
/*   Updated: 2021/03/19 19:47:40 by rvena            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int worldMap[mapHeight][mapWidth]=
{
	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
	{1,0,6,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,2,2,2,2,2,0,0,0,0,3,0,3,0,3,0,0,0,1},
	{1,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,2,0,5,0,2,0,0,0,0,3,0,5,0,3,0,0,0,1},
	{1,0,0,0,0,0,2,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,2,2,0,2,2,0,0,0,0,3,0,3,0,3,0,0,0,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,4,0,4,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,4,0,0,0,0,5,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,4,0,4,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,4,0,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,4,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
	{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
};

int				movement(player_data *player)
{
	if(player->mF == 1)
	{
		if(worldMap[(int)((player->posY + player->dirY * 0.5))][(int)(player->posX)] == 0 ||
			worldMap[(int)((player->posY + player->dirY * 0.5))][(int)(player->posX)] == 6)    
				player->posY += player->dirY * player->moveSpeed * 0.25;
		if(worldMap[(int)(player->posY)][(int)((player->posX + player->dirX * 0.5)) ] == 0 ||
			worldMap[(int)(player->posY)][(int)((player->posX + player->dirX * 0.5)) ] == 6)
				player->posX += player->dirX * player->moveSpeed * 0.25;
	}
	if(player->mB == 1)
	{
		if(worldMap[(int)((player->posY - player->dirY * player->moveSpeed* 0.5) )][(int)(player->posX)] == 0 ||
			worldMap[(int)((player->posY - player->dirY * player->moveSpeed* 0.5) )][(int)(player->posX)] == 6)
				player->posY -= player->dirY * player->moveSpeed * 0.25;
		if(worldMap[(int)(player->posY)][(int)((player->posX - player->dirX * player->moveSpeed* 0.5) )] == 0 || 
			worldMap[(int)(player->posY)][(int)((player->posX - player->dirX * player->moveSpeed* 0.5) )] == 6)
				player->posX -= player->dirX * player->moveSpeed * 0.25;
	}
	return(0);
}

int 	render_next_frame(all_data *everything)
{
	mlx_clear_window(everything->img->mlx_ptr, everything->img->win_ptr);
    mlx_clear_window(everything->minimap->mlx_ptr, everything->minimap->win_ptr);
	//movement(everything->player);
    drawFOV(everything, worldMap);
	setAndSort(everything, everything->listOfSprites);
	mlx_put_image_to_window(everything->img->mlx_ptr, everything->img->win_ptr, everything->img->ind, 0, 0);
	return (0);
}

int             key_hook_release(int keycode, player_data *player)
{
	if(keycode == 13)
		player->mF = 0;
	if(keycode == 1)
		player->mB = 0;
	printf("it works\n");
	return (0);
}

int             key_hook(int keycode, player_data *player)
{
	if (keycode == 123)
	{
		player->rL = 1;
        double oldDirX = player->dirX;
        player->dirX = player->dirX * cos((player->rotSpeed)) - player->dirY * sin((player->rotSpeed));
        player->dirY = oldDirX * sin((player->rotSpeed)) + player->dirY * cos((player->rotSpeed));
        double oldPlaneX = player->planeX;
        player->planeX = player->planeX * cos((player->rotSpeed)) - player->planeY * sin((player->rotSpeed));
        player->planeY = oldPlaneX * sin((player->rotSpeed)) + player->planeY * cos((player->rotSpeed));
    }
	if (keycode == 124)
    {
        double oldDirX = player->dirX;
        player->dirX = player->dirX * cos(-1*(player->rotSpeed)) - player->dirY * sin(-1*(player->rotSpeed));
        player->dirY = oldDirX * sin(-1*(player->rotSpeed)) + player->dirY * cos(-1*(player->rotSpeed));
        double oldPlaneX = player->planeX;
        player->planeX = player->planeX * cos(-1*(player->rotSpeed)) - player->planeY * sin(-1*(player->rotSpeed));
        player->planeY = oldPlaneX * sin(-1*(player->rotSpeed)) + player->planeY * cos(-1*(player->rotSpeed));
    }
    if (keycode == 13)
    {
		player->mF = 1;
        if(worldMap[(int)((player->posY + player->dirY * 0.5))][(int)(player->posX)] == 0 ||
            worldMap[(int)((player->posY + player->dirY * 0.5))][(int)(player->posX)] == 6)    
                player->posY += player->dirY * player->moveSpeed * 0.25;
        if(worldMap[(int)(player->posY)][(int)((player->posX + player->dirX * 0.5)) ] == 0 ||
            worldMap[(int)(player->posY)][(int)((player->posX + player->dirX * 0.5)) ] == 6)
                player->posX += player->dirX * player->moveSpeed * 0.25;
    }
    if (keycode == 1)
    {
		player->mB = 1;
        if(worldMap[(int)((player->posY - player->dirY * player->moveSpeed* 0.5) )][(int)(player->posX)] == 0 ||
            worldMap[(int)((player->posY - player->dirY * player->moveSpeed* 0.5) )][(int)(player->posX)] == 6)
                player->posY -= player->dirY * player->moveSpeed * 0.25;
        if(worldMap[(int)(player->posY)][(int)((player->posX - player->dirX * player->moveSpeed* 0.5) )] == 0 ||
            worldMap[(int)(player->posY)][(int)((player->posX - player->dirX * player->moveSpeed* 0.5) )] == 6)
                player->posX -= player->dirX * player->moveSpeed * 0.25;
    }
	if (keycode == 0)
	{
		if(worldMap[(int)((player->posY + player->planeY * 0.5))][(int)(player->posX)] == 0 ||
            worldMap[(int)((player->posY + player->planeY * 0.5))][(int)(player->posX)] == 6)    
                player->posY -= player->planeY * player->moveSpeed * 0.25;
        if(worldMap[(int)(player->posY)][(int)((player->posX + player->planeX * 0.5)) ] == 0 ||
            worldMap[(int)(player->posY)][(int)((player->posX + player->planeX * 0.5)) ] == 6)
                player->posX -= player->planeX * player->moveSpeed * 0.25;
	}
	if (keycode == 2)
	{
		if(worldMap[(int)((player->posY + player->planeY * 0.5))][(int)(player->posX)] == 0 ||
            worldMap[(int)((player->posY + player->planeY * 0.5))][(int)(player->posX)] == 6)    
                player->posY += player->planeY * player->moveSpeed * 0.25;
		if(worldMap[(int)(player->posY)][(int)((player->posX + player->planeX * 0.5)) ] == 0 ||
			worldMap[(int)(player->posY)][(int)((player->posX + player->planeX * 0.5)) ] == 6)
				player->posX += player->planeX * player->moveSpeed * 0.25;
	}
	printf("%i\n", keycode);
	return(0);
}

void            my_mlx_pixel_put(t_data *data, int x, int y, int color)
{
    char    *dst;

    dst = data->addr + (y * data->line_length + x * (data->bits_per_pixel / 8));
    *(unsigned int*)dst = color;
}

void			put_square(t_data img, int col)
{
	int x;
	int y;

	x = 0;
	y = 0;

	while(y < 10)
	{
		x = 0;
		while(x < 10)
		{
			if(col == 0)
				my_mlx_pixel_put(&img, x, y, 0xFFFFFF);
			else 
				my_mlx_pixel_put(&img, x, y, 0x0000FF00);
			x++;
		}
		y++;
	}
}

void changeMap(int **worldMap)
{
    worldMap[1][5] = 8;
}

int main(void)
{
    t_data img;
    t_data minimap;
    t_data minimapPlayer;
    
    player_data player;
    player.dirX = 1;
    player.dirY = 0;
    player.planeX = 0;
    player.planeY = 0.66;
    player.rotSpeed = 6;
    player.moveSpeed = 1;

	ray_data	raycasting;
	all_data	everything;
	tex_data	texture1;
	tex_data	sprite1;
	sprite_data	*listOfSprites;
	sprite_data *tmp;
	double		Zbuffer[screenWidth];

	listOfSprites = NULL;

    everything.player = &player;
    everything.img = &img;
    everything.raycasting = &raycasting;
    everything.minimap = &minimap;
    everything.minimapPlayer = &minimapPlayer;
    everything.texture = &texture1;
	everything.sprite1 = &sprite1;
	everything.listOfSprites = listOfSprites;
	everything.numOfSprite = 0;
    
    img.mlx_ptr = mlx_init();
    img.win_ptr = mlx_new_window(img.mlx_ptr, screenWidth, screenHeight, "Raycasting");
    
    minimap.mlx_ptr = mlx_init();
    minimap.win_ptr = mlx_new_window(minimap.mlx_ptr, screenWidth, screenHeight, "MiniMap");
    minimap.x = 0;
    minimap.y = 0;

    img.x = 0;
	img.y = 0;
	img.ind = mlx_new_image(img.mlx_ptr, screenWidth, screenHeight);
	img.addr = mlx_get_data_addr(img.ind, &img.bits_per_pixel, &img.line_length,
									&img.endian);

    texture1.relative_path = "gomer.png";
    texture1.ind = mlx_png_file_to_image(img.mlx_ptr, "gomer.png", &texture1.texWidth, &texture1.texHeight);
    texture1.addr = mlx_get_data_addr(texture1.ind, &texture1.bits_per_pixel, 
                                    &texture1.line_length, &texture1.endian);
	
	sprite1.relative_path = "barrel.png";
	sprite1.texHeight = 0;
	sprite1.texWidth = 0;
	sprite1.ind = mlx_png_file_to_image(img.mlx_ptr, "barrel.png", &sprite1.texWidth, &sprite1.texHeight);
	sprite1.addr = mlx_get_data_addr(sprite1.ind, &sprite1.bits_per_pixel, 
									&sprite1.line_length, &sprite1.endian);

    minimap.ind = mlx_new_image(minimap.mlx_ptr, screenWidth, screenHeight);
    minimap.addr = mlx_get_data_addr(minimap.ind, &minimap.bits_per_pixel, &minimap.line_length, &minimap.endian);

    minimapPlayer.ind = mlx_new_image(minimap.mlx_ptr, 11, 11);
    minimapPlayer.addr = mlx_get_data_addr(minimapPlayer.ind, &minimapPlayer.bits_per_pixel, &minimapPlayer.line_length, &minimapPlayer.endian);

    put_square(minimap, 0);
    put_square(minimapPlayer, 1);

	// listOfSprites = (sprite_data *)malloc(sizeof(sprite_data) * (5) + 1);
	int sprX;
	int sprY;
	int k = 0;

	sprX = 0;
	sprY = 0;

    for (int i = 0; i < mapHeight; i++)
    {
        for (int j = 0; j < mapWidth; j++)
        {
            if(worldMap[i][j] == 6)
            {
                player.posX = j + 0.5;
                player.posY = i + 0.5;
                mlx_put_image_to_window(minimap.mlx_ptr, minimap.win_ptr, minimapPlayer.ind, j * 10, i * 10);
            }
			if(worldMap[i][j] == 5)
			{
				everything.numOfSprite++;
				tmp = everything.listOfSprites;
				// printf("numOfSprite = %d\n", everything.numOfSprite);
				everything.listOfSprites = (sprite_data *)malloc(sizeof(sprite_data) * (everything.numOfSprite));
				for(int l = 0; l < everything.numOfSprite - 1; l++)
				{
					everything.listOfSprites[l].x = tmp[l].x;
					everything.listOfSprites[l].y = tmp[l].y;
				}
				everything.listOfSprites[everything.numOfSprite - 1].x = j + 0.5;
				everything.listOfSprites[everything.numOfSprite - 1].y = i + 0.5;
				free(tmp);
				//k++;
			}
            else if(worldMap[i][j] > 0)
                mlx_put_image_to_window(minimap.mlx_ptr, minimap.win_ptr, minimap.ind, j * 10, i * 10);
        }
    }
	everything.spriteOrder = (int *)malloc(sizeof(int) * everything.numOfSprite);
	everything.spriteDist = (double *)malloc(sizeof(double) * everything.numOfSprite);
	// printf("\n");
	// printf("unsorted listOfSprites\n");
	// for(int i = 0; i < 5; i++)
	// {
	// 	printf("listOfSprites[%d].x = %d\n", i, everything.listOfSprites[i].x);
	// 	printf("listOfSprites[%d].y = %d\n", i, everything.listOfSprites[i].y);
	// }
	
    // drawFOV(&everything, worldMap);
	// printf("DrawFOV is finished\n");
    // setAndSort(&everything, everything.listOfSprites);
	//printf("Preimage put\n");
    // printf("player.posX = %f\nplayer.posY = %f\n", player.posX, player.posY);
    mlx_put_image_to_window(img.mlx_ptr, img.win_ptr, img.ind, 0, 0);
    // printf("Image was put to window\n");
    mlx_hook(img.win_ptr, 2, 1L<<0, key_hook, everything.player);
	mlx_hook(img.win_ptr, 3, 1L<<0, key_hook_release, everything.player);
    mlx_loop_hook(img.mlx_ptr, render_next_frame, &everything);
    mlx_loop(img.mlx_ptr);
    
}
